
package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.myapplication.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity
        implements Fragment2.OnContinueClickListener,
        Fragment3.OnCheckListener {

    private ActivityMainBinding binding;

    private int currentFragment = 1;
    private String name;

    Fragment2 fragment2 = new Fragment2();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Fragment1 fragment1 = Fragment1.newInstance(null, null);

        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.fragment_container, fragment1)
                .commit();

        binding.buttonContinue.setOnClickListener(view -> {
            if (currentFragment == 1) {
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragment_container, fragment2)
                        .addToBackStack(null)
                        .commit();

                currentFragment = 2;

            } else if (currentFragment == 2) {

                fragment2.sendData();
            }
        });
    }

    @Override
    public void onContinueClick(String name) {
    }

    @Override
    public void onContinueClick(String name, String email,
                                String gender, String age) {

        Bundle bundle = new Bundle();
        bundle.putString("name", name);
        bundle.putString("email", email);
        bundle.putString("gender", gender);
        bundle.putString("age", age);

        Fragment3 fragment3 = new Fragment3();
        fragment3.setArguments(bundle);

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment3)
                .addToBackStack(null)
                .commit();

        currentFragment = 3;
        binding.buttonContinue.setVisibility(View.GONE);
    }

    @Override
    public void onCheckChanged(boolean checked) {

        Fragment3 fragment3 = (Fragment3)
                getSupportFragmentManager()
                        .findFragmentById(R.id.fragment_container);

        if (fragment3 != null) {
            fragment3.changeButton(checked);
        }
    }
}
