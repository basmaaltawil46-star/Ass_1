
package com.example.myapplication;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.databinding.Fragment2Binding;

public class Fragment2 extends Fragment {

    public interface OnContinueClickListener {
        void onContinueClick(String name);

        void onContinueClick(String name,
                             String email,
                             String gender,
                             String age);
    }

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        if (context instanceof OnContinueClickListener) {
            listener = (OnContinueClickListener) context;
        }
    }

    private OnContinueClickListener listener;
    public Fragment2Binding fragment2Binding;

    public Fragment2() {
    }

    public static Fragment2 newInstance(String param1, String param2) {
        Fragment2 fragment = new Fragment2();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        fragment2Binding = Fragment2Binding.inflate(inflater, container, false);
        return fragment2Binding.getRoot();
    }

    public void sendData() {

        String name = fragment2Binding.editText.getText().toString();
        String email = fragment2Binding.emailId.getText().toString();
        String gender = fragment2Binding.genderId.getText().toString();
        String age = fragment2Binding.ageId.getText().toString();

        if (!name.isEmpty()) {
            listener.onContinueClick(name, email, gender, age);
        } else {
            Toast.makeText(getContext(), "Enter name!",
                    Toast.LENGTH_SHORT).show();
        }
    }
}
