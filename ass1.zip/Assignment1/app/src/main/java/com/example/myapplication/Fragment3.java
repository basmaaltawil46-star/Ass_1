
package com.example.myapplication;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.annotation.NonNull;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.myapplication.databinding.Fragment3Binding;

public class Fragment3 extends Fragment {

    private Fragment3Binding binding;

    private String name;
    private String email;
    private String gender;
    private String age;

    // Interface
    public interface OnCheckListener {
        void onCheckChanged(boolean checked);
    }

    private OnCheckListener listener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        listener = (OnCheckListener) context;
    }

    public Fragment3() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        binding = Fragment3Binding.inflate(inflater, container, false);

        if (getArguments() != null) {
            name = getArguments().getString("name");
            email = getArguments().getString("email");
            gender = getArguments().getString("gender");
            age = getArguments().getString("age");

            binding.textId.setText(
                    "Name: " + name +
                            "\nEmail: " + email +
                            "\nGender: " + gender +
                            "\nAge: " + age
            );
        }

        binding.checkBoxId.setOnCheckedChangeListener(
                (buttonView, isChecked) -> {
                    listener.onCheckChanged(isChecked);
                }
        );

        return binding.getRoot();
    }

    public void changeButton(boolean checked) {

        if (checked) {
            binding.buttonId.setEnabled(true);
            binding.buttonId.setText("Finish");
        } else {
            binding.buttonId.setEnabled(false);
            binding.buttonId.setText("Continue");
        }
    }
}
